# Meta ads — Android APK Project

Is project mein tumhari existing dashboard HTML `app/src/main/assets/index.html` mein bundled hai. App page ko local asset se kholta hai; dashboard ka HTML app ke andar hai.

## Video
HTML mein shared `GITHUB_VIDEO_URL` set hai:
`https://raw.githubusercontent.com/mukulnishad091/Ads_videos/main/lv_0_20260401161006.mp4`

HTML offline bundled hai, lekin GitHub par hosted video ko stream karne ke liye internet zaroori hai. Agar video URL/file badlo, isi HTML constant ko update karke APK dobara build karo.

## Android Studio se APK build
1. ZIP extract karo.
2. Android Studio kholo → **Open** → extracted `Meta_ads_Android_Project` folder select karo.
3. Gradle sync complete hone do. JDK 17 use karo (Android Studio embedded JDK recommended).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** select karo.
5. Debug APK path: `app/build/outputs/apk/debug/app-debug.apk`.
6. APK ko Android phone par transfer karke install karo. Agar prompt aaye toh is source se app install permission allow karo.

## Command line (Android SDK + JDK 17 required)
Project folder ke andar:
`gradle assembleDebug`

Agar `gradle` command installed nahi hai, Android Studio se build karo. Project mein Gradle wrapper include nahi hai.

## Notes
- App label: **Meta ads**.
- Minimum Android version: Android 6.0 (API 23).
- Internet permission sirf remote GitHub MP4 playback ke liye bhi zaroori hai.
- Ye Android Studio project hai, compiled APK nahi. Is environment mein Android SDK/Gradle build verify nahi kiya gaya.
